﻿namespace ETModel
{
	public static class EventIdType
	{
		public const string NumbericChange = "NumbericChange";
	}
}