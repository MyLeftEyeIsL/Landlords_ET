﻿namespace ETModel
{
    public static partial class ActorInterceptType
    {
	    public const string None = "None";
		public const string GateSession = "GateSession";
    }
}
