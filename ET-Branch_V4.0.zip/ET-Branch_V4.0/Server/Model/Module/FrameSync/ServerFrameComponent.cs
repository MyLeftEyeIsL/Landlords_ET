﻿namespace ETModel
{
	public class ServerFrameComponent: Component
	{
		public int Frame;

		public FrameMessage FrameMessage;
	}
}
