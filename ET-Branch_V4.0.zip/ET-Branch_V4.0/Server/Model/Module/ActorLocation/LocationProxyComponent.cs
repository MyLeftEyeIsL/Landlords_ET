﻿using System.Net;
using System.Threading.Tasks;

namespace ETModel
{
	public class LocationProxyComponent : Component
	{
		public IPEndPoint LocationAddress;
	}
}